package com.common.control.interfaces;

public interface PurchaseCallback {
    void purchaseSuccess();
    void purchaseFail();
}
